# Silex v1 research package

Silex is an experimental visual semantic language with 64 six-site glyphs,
scoped compositional syntax, paid local definitions, and direct/compressed
binary writing profiles. The native digital codec is implemented. A complete
semantic model interpreter and a human readability study are not included.

## Start here

- `Silex-Laboratory.html`: self-contained, offline specimen explorer and full specification.
- `Silex-Research-Report.pdf`: 21-page printable research report.
- `Silex-Specification.md`: editable complete report.
- `Grammar-and-Semantics.md`: standalone language reference.
- `glyph-atlas.png` and `written-specimens.png`: actual glyphs and complete utterances.
- `silex-01.png` through `silex-13.png`: native 2-pixel-module writing.
- `silex_codec.py`: reference encoder/decoder.
- `benchmark.csv`, `results.json`, and the verification/provenance records: raw evidence.

The ZIP preserves an `outputs/` and `work/` layout. The latter contains only
reproduction sources, not temporary screenshots. Open the laboratory directly
in a browser; no server or internet connection is needed.

## What the measurements support

With 32-pixel em height for both native glyphs and conventional fonts, the full
13-example sample uses about 8.6% less area than English and 16.3% more than
Mandarin. With all three sources compressed and placed in the same binary
carrier, the measured carrier-area ratios are 1.535
for English and 1.935 for Mandarin relative to Silex.
These are demonstration measurements conditional on a shared dictionary and
selected formal readings, not a measured semantic entropy or a population result.
The typography/2-pixel-binary comparison does not match human recognition error.
Mandarin glosses are authored translations without independent native review.

The explicitly measured engineering bootstrap is 39,794
bytes, or 14,531 after zlib compression. It assumes an English-reading
programmer with the specified runtime and background knowledge. It excludes
human learning time, fonts, and additional world grounding; it is not a minimum
or complete cognitive decoder cost.

## Use the codec

From the `outputs/` directory:

```
python3 silex_codec.py '(SEE ME YOU)' --png message.png --svg message.svg
python3 silex_codec.py --decode-png message.png
```

The default selects the smaller complete frame from direct and compressed
profiles. Add `--direct` to force the native head-glyph stream.
Core encoding uses the Python standard library; PNG operations require Pillow.

## Reproduce

From the ZIP's `silex/` directory:

```
python3 work/verify_codec.py
python3 work/build_experiment.py
python3 work/build_report.py
```

The benchmark uses the recorded macOS Arial and Arial Unicode font files.
Their exact paths and hashes are in `rendering-provenance.json`; replacing fonts
changes the results. The report builder also uses Arial Bold. Python rendering
packages used here: Pillow 12.3.0 and ReportLab 4.4.9.
The codec and syntax tests do not require the macOS fonts. The report requires
Pillow and ReportLab. No fonts are redistributed.

`verification.json` records executed codec checks. `laboratory-verification.json`
records 26 frames checked against Python and desktop/tablet/mobile browser checks.
`document-verification.json` records the rendered report pages. `manifest.json`
provides SHA-256 hashes for all archived deliverables and reproduction sources.
